// background.js
const trustList = ['google.com', 'microsoft.com', 'github.com', 'amazon.com', 'apple.com'];

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_RISK_DATA") {
        const url = sender.tab.url;
        
        // Skip browser-internal pages where scripts are blocked
        if (!url || !url.startsWith('http')) {
            sendResponse({ score: 0 });
            return true;
        }

        const domain = new URL(url).hostname;
        let risk = 0;

        // Logic: No SSL (+30), Unknown Domain (+45)
        if (url.startsWith('http:')) risk += 30;
        if (!trustList.some(t => domain.includes(t))) risk += 45;

        const result = { score: Math.min(risk, 100), domain: domain };

        // Save and respond
        chrome.storage.local.set({ [domain]: result }, () => {
            sendResponse(result);
        });

        return true; // Keeps message channel open
    }
});