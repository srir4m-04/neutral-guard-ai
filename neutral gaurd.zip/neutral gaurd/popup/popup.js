document.addEventListener('DOMContentLoaded', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.startsWith('http')) return;

    const domain = new URL(tab.url).hostname;

    chrome.storage.local.get([domain], (result) => {
        const data = result[domain] || { score: 10 };
        const score = data.score;

        // 1. Determine Colors and Labels
        let color, bannerText, glow;

        if (score > 70) {
            color = "#ff004c"; // Red
            bannerText = "DANGEROUS SITE";
            glow = "0 0 20px rgba(255, 0, 76, 0.7)";
        } else if (score >= 30) {
            color = "#ff9500"; // Orange
            bannerText = "CAUTION: UNKNOWN";
            glow = "0 0 20px rgba(255, 149, 0, 0.7)";
        } else {
            color = "#00ff88"; // Green
            bannerText = "SITE VERIFIED SAFE";
            glow = "0 0 20px rgba(0, 255, 136, 0.7)";
        }

        // 2. Select Elements
        const banner = document.getElementById('banner');
        const ring = document.getElementById('riskRing');
        const scoreNum = document.getElementById('scoreNum');
        const secureBtn = document.querySelector('.action-btn'); 
        const historyBtn = document.querySelector('.secondary-btn');

        // 3. Apply Global UI Updates
        if(scoreNum) scoreNum.innerText = score;
        if(banner) {
            banner.innerText = bannerText;
            banner.style.backgroundColor = color;
            banner.style.boxShadow = glow;
        }
        
        if(ring) {
            ring.style.stroke = color;
            ring.style.strokeDasharray = `${score}, 100`;
            ring.style.filter = `drop-shadow(0 0 5px ${color})`;
        }

   // 4. Update Secure Session Button & Functionality
if (secureBtn) {
    secureBtn.style.backgroundColor = color;
    secureBtn.style.boxShadow = glow;

    if (score > 70) {
        secureBtn.innerText = "TERMINATE SESSION";
        // ADD THIS LINE: This starts the blinking
        secureBtn.classList.add('blink-active'); 
        
        secureBtn.onclick = () => {
            chrome.tabs.remove(tab.id);
        };
    } else {
        secureBtn.innerText = "SECURE SESSION";
        // REMOVE BLINK: Ensure it doesn't blink for safe sites
        secureBtn.classList.remove('blink-active');
        
        secureBtn.onclick = () => {
            alert("Security Active: Your session on " + domain + " is protected.");
        };
    }
}
// Inside your score logic:
const openSettingsBtn = document.getElementById('openSettings');

if (score < 30) {
    color = "#00ff88"; // Green
    glow = "0 0 20px rgba(0, 255, 136, 0.5)";
} else if (score <= 70) {
    color = "#ffaa00"; // Orange
    glow = "0 0 20px rgba(255, 170, 0, 0.5)";
} else {
    color = "#ff004c"; // Red
    glow = "0 0 20px rgba(255, 0, 76, 0.5)";
}

// Update the settings button color to match the UI theme
if (openSettingsBtn) {
    openSettingsBtn.style.borderColor = color;
    openSettingsBtn.style.color = color;
    openSettingsBtn.style.boxShadow = glow;
}

        // 5. Adapt View History Button color
        if (historyBtn) {
            historyBtn.style.borderColor = color; 
            historyBtn.onclick = () => chrome.tabs.create({ url: 'history/history.html' });

            historyBtn.onmouseenter = () => {
                historyBtn.style.boxShadow = `0 0 10px ${color}`;
                historyBtn.style.color = color;
            };
            historyBtn.onmouseleave = () => {
                historyBtn.style.boxShadow = "none";
                historyBtn.style.color = "white";
            };
        }

        // --- NEW: UPDATED HISTORY SAVING LOGIC ---
        const historyEntry = {
            domain: domain,
            score: score,
            // Added toLocaleString to capture the exact time
            date: new Date().toLocaleString([], { 
                year: 'numeric', 
                month: 'numeric', 
                day: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit' 
            })
        };

        chrome.storage.local.get(['scanHistory'], (data) => {
            let history = data.scanHistory || [];
            
            // Logic to prevent duplicate entries from spamming the history
            const isDuplicate = history.length > 0 && 
                               history[0].domain === domain && 
                               history[0].date === historyEntry.date;

            if (!isDuplicate) {
                history.unshift(historyEntry);
                // Keep only the last 50 entries
                chrome.storage.local.set({ 'scanHistory': history.slice(0, 50) }); 
            }
        });
        // -------------------------------------------------------------
    });
});