import whois
import tldextract
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
# CRITICAL: This allows your Chrome Extension to talk to Python
CORS(app)

def get_domain_age(domain):
    try:
        # Some WHOIS servers return a list, some a single date
        w = whois.whois(domain)
        creation_date = w.creation_date
        
        if not creation_date:
            return 0
            
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        
        # Ensure we have a valid datetime object
        if isinstance(creation_date, datetime):
            age_days = (datetime.now() - creation_date).days
            return age_days
        return 0
    except Exception as e:
        print(f"WHOIS Error for {domain}: {e}")
        return 0 

@app.route('/analyze', methods=['POST'])
def analyze_url():
    try:
        data = request.get_json()
        if not data or 'url' not in data:
            return jsonify({"error": "No URL provided"}), 400

        url = data.get('url', '').lower()
        
        # --- 1. WHITELIST CHECK (VIP LIST) ---
        # We do this FIRST so safe sites bypass all scoring logic
        whitelist = ["google.com", "wikipedia.org", "github.com", "amazon.com", "microsoft.com", "apple.com", "youtube.com"]
        
        ext = tldextract.extract(url)
        domain = f"{ext.domain}.{ext.suffix}"

        if any(trusted in domain for trusted in whitelist):
            print(f"WHITELIST HIT: {domain} is verified safe.")
            return jsonify({
                "status": "success",
                "logic_version": "2.0_Stable", 
                "risk_score": 0,
                "reasons": ["Verified Trusted Domain"],
                "domain": domain
            })

        # --- 2. RISK SCORING LOGIC ---
        score = 0
        reasons = []

        # SSL Check
        if url.startswith("http://"):
            score += 50
            reasons.append("Insecure Connection (No SSL)")

        # Phishing Keywords Check
        keywords = ["login", "verify", "secure", "bank", "update", "account", "signin"]
        has_keyword = any(key in url for key in keywords)
        if has_keyword:
            score += 30
            reasons.append("Suspicious Keywords Detected")

        # Combination Bonus
        if url.startswith("http://") and has_keyword:
            score += 20 
            reasons.append("High-Risk Combination: Insecure + Phishing Terms")

        # URL Structure Check
        if "@" in url or url.count(".") > 3:
            score += 20
            reasons.append("Suspicious URL Structure")

        # Domain Age Check
        if domain and "." in domain:
            age = get_domain_age(domain)
            if 0 < age < 365:
                score += 40
                reasons.append(f"Newly Created Domain ({age} days old)")
            elif age == 0:
                # This only triggers if the site isn't on the whitelist
                score += 25 
                reasons.append("Domain Age Unverifiable")

        # --- 3. FINAL CALCULATION ---
        final_score = min(score, 100)
        # If the score is perfectly clean, we still show 1% to show the AI is active
        if final_score == 0: final_score = 1

        return jsonify({
            "status": "success",
            "logic_version": "2.0_Stable", 
            "risk_score": final_score,
            "reasons": reasons,
            "domain": domain
        })

    except Exception as e:
        print(f"Server Error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    print("Neutral Guard AI Backend Starting...")
    # debug=True allows the server to auto-reload when you save this file
    app.run(host="127.0.0.1", port=5000, debug=True)