document.addEventListener('DOMContentLoaded', () => {
    const historyList = document.getElementById('historyList');
    const exportBtn = document.getElementById('exportPdf');
    const clearBtn = document.getElementById('clearHistory');

    // 1. Fetch and Display History
    chrome.storage.local.get(['scanHistory'], (result) => {
        const history = result.scanHistory || [];
        if (history.length === 0) {
            historyList.innerHTML = '<p>No scans found.</p>';
            return;
        }
        historyList.innerHTML = history.map(item => `
            <div class="history-item" style="border-left: 5px solid ${getRiskColor(item.score)}">
                <div class="history-details">
                    <span><strong>${item.domain}</strong></span><br>
                    <small>${item.date}</small>
                </div>
                <div class="score-badge" style="background:${getRiskColor(item.score)}">${item.score}%</div>
            </div>
        `).join('');
    });

    // 2. Export PDF
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            chrome.storage.local.get(['scanHistory'], (result) => {
                const logs = result.scanHistory || [];
                if (logs.length === 0) return alert("Nothing to export!");

                doc.setFontSize(18);
                doc.text("Neutral Guard AI - Scan History", 20, 20);
                doc.line(20, 25, 190, 25);

                logs.forEach((item, i) => {
                    doc.setFontSize(12);
                    doc.text(`${i + 1}. ${item.domain} (Score: ${item.score}%)`, 20, 35 + (i * 10));
                });

                doc.save("NeutralGuard_Report.pdf");
            });
        });
    }

    // 3. Clear History
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (confirm("Clear all scan data?")) {
                chrome.storage.local.remove('scanHistory', () => location.reload());
            }
        });
    }
});

function getRiskColor(score) {
    if (score > 70) return "#ff004c";
    if (score >= 30) return "#ff9500";
    return "#00ff88";
}