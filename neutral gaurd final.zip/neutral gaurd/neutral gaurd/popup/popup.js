document.addEventListener('DOMContentLoaded', async () => {
    // 1. Get current tab URL
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.startsWith('http')) {
        document.getElementById('banner').innerText = "INVALID PAGE";
        return;
    }

    const currentUrl = tab.url;
    const domain = new URL(currentUrl).hostname;
    
    // UI Elements
    const banner = document.getElementById('banner');
    const ring = document.getElementById('riskRing');
    const scoreNum = document.getElementById('scoreNum');
    const secureBtn = document.querySelector('.action-btn');
    const historyBtn = document.querySelector('.secondary-btn');
    const openSettingsBtn = document.getElementById('openSettings');

    // Show "Analyzing" state
    if (banner) banner.innerText = "ANALYZING...";

    try {
        // 2. FETCH NEW DATA FROM BACKEND
        const response = await fetch('http://127.0.0.1:5000/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: currentUrl })
        });

        const backendData = await response.json();
        const score = backendData.risk_score;
        const reasons = backendData.reasons || [];

        // 3. Determine Colors and Labels based on Backend Score
        let color, bannerText, glow;

        if (score > 70) {
            color = "#ff004c"; // Red
            bannerText = "DANGEROUS SITE";
            glow = "0 0 20px rgba(255, 0, 76, 0.7)";
        } else if (score >= 30) {
            color = "#ff9500"; // Orange
            bannerText = "CAUTION: UNKNOWN";
            glow = "0 0 20px rgba(255, 149, 0, 0.7)";
        } else {
            color = "#00ff88"; // Green
            bannerText = "SITE VERIFIED SAFE";
            glow = "0 0 20px rgba(0, 255, 136, 0.7)";
        }

        // 4. Apply UI Updates
        if (scoreNum) scoreNum.innerText = score;
        if (banner) {
            banner.innerText = bannerText;
            banner.style.backgroundColor = color;
            banner.style.boxShadow = glow;
        }
        
        if (ring) {
            ring.style.stroke = color;
            ring.style.strokeDasharray = `${score}, 100`;
            ring.style.filter = `drop-shadow(0 0 5px ${color})`;
        }

        if (openSettingsBtn) {
            openSettingsBtn.style.borderColor = color;
            openSettingsBtn.style.color = color;
            openSettingsBtn.style.boxShadow = glow;
        }

        // 5. Update Secure Session Button
        if (secureBtn) {
            secureBtn.style.backgroundColor = color;
            secureBtn.style.boxShadow = glow;

            if (score > 70) {
                secureBtn.innerText = "TERMINATE SESSION";
                secureBtn.classList.add('blink-active'); 
                secureBtn.onclick = () => chrome.tabs.remove(tab.id);
            } else {
                secureBtn.innerText = "SECURE SESSION";
                secureBtn.classList.remove('blink-active');
                secureBtn.onclick = () => alert("Security Active: " + domain + " is protected.");
            }
        }

       if (historyBtn) {
            // Only update the border color dynamically based on score
            historyBtn.style.borderColor = color; 
            
            // Set text to white explicitly here as well
            historyBtn.style.color = "white"; 
            
            // Remove the hardcoded glow from JS so the CSS :hover can take over
            historyBtn.style.boxShadow = "none"; 

            // Handle the dynamic hover glow using listeners
            historyBtn.onmouseenter = () => {
                historyBtn.style.boxShadow = `0 0 8px ${color}80`; // Added '80' for 50% opacity
            };
            historyBtn.onmouseleave = () => {
                historyBtn.style.boxShadow = "none";
            };

            historyBtn.onclick = () => chrome.tabs.create({ url: 'history/history.html' });
        }

        // 6. SAVE NEW RESULTS TO HISTORY
        const historyEntry = {
            domain: domain,
            score: score,
            reasons: reasons,
            date: new Date().toLocaleString([], { 
                year: 'numeric', month: 'numeric', day: 'numeric', 
                hour: '2-digit', minute: '2-digit' 
            })
        };

        chrome.storage.local.get(['scanHistory'], (result) => {
            let history = result.scanHistory || [];
            // Remove previous entry for same domain to keep history clean
            history = history.filter(item => item.domain !== domain);
            history.unshift(historyEntry);
            chrome.storage.local.set({ 'scanHistory': history.slice(0, 50) });
        });

    } catch (error) {
        console.error("Backend offline:", error);
        if (banner) {
            banner.innerText = "API OFFLINE";
            banner.style.backgroundColor = "#555";
        }
    }
});